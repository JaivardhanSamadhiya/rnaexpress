# SRLE fixed-choice and exact-uniform risk arithmetic replay

Run `python -I -S -B replay.py` in this extracted directory. Python standard
library only: no installation, network, source repository, raw outcomes or
sequence identifiers are needed. The replay reads only explicit package members.

This validates aggregation arithmetic, not training, candidate enumeration,
biological replication, model selection, source measurements or an experimental
success gate. These are conditional, posthoc summaries from a shared constituent
experiment. PASS means that anonymous class aggregates reproduce archived
numbers; it does not mean that an independent biological hypothesis passed.

All four models and both requested directions are retained. The 60 composition
classes contain 592 retained parents; each class has equal weight. Percentages
are class-balanced means, not unweighted percentages of 592 parents. Positive
directed change is movement in the requested NRS direction. Negative change
means the opposite direction, not toxicity. NRS is a log2 compartment ratio,
not a percentage of molecules. The 0.1 scale is descriptive, not a validated
biological cutoff.

The fixed summaries contain 152 statistics, and the exact-uniform reference and
literal model-minus-uniform comparisons contain 190 statistics. Each has one
estimate and two descriptive CI endpoints: 1,026 numeric comparisons total.
Means use equally weighted sorted class IDs 0..59. The supplied 2,000 x 60
bootstrap indices were generated once with NumPy 1.26.4 default_rng(20260921),
integers(0,60,size=(2000,60)), and shared across every summary and contrast.
Replay uses math.fsum means and linear quantiles at 0.025 and 0.975; maximum
allowed absolute discrepancy is 1e-12. These CIs omit training uncertainty.

The uniform source summaries average all measured candidates per parent and
hold one candidate identity fixed across paired replicates. Nonlinear metrics
were computed per candidate before averaging. This package starts from saved
class aggregates and DOES NOT independently rederive candidate choices,
within-parent averages, sequence matching or the exact-uniform enumeration.
The comparison is model minus uniform for every metric, without sign reversal.
Higher benefit/mean and lower harm/loss are favorable; a positive difference
is not uniformly favorable across metrics. No new performance criterion is set.

Checks cover exact file/schema membership, SHA256 hashes, all expected class /
model / direction / replicate cells, consistent parent counts, finite values,
valid sign fractions, and all 342 estimates plus 684 CI endpoints. Original
result JSONs and specs are included for provenance. Metadata about original
rows, frozen sources and candidate rosters is carried from those results and
is not revalidated by anonymous aggregates. No raw source outcomes or sequences
are included. SHA256 verifies consistency with the supplied manifest; it is
not an authenticity guarantee if an adversary replaces both files and manifest.

The package builder and archive receipt remain in the source project. The
archive uses a fixed member allowlist and explicit safe extraction for its
isolated standard-library validation.
