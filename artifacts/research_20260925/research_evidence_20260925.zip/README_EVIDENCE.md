# RNA-localization evidence delivery, 25 September 2026

Start with reports/research_20260921/research_synthesis_20260925.md.
The result is bounded Outcome B, with PARTIAL SRLE source provenance.
No novel mechanism, independent confirmation or competition outcome is claimed.
This package is an AI-authored audit; it is not student submission prose.

Tables are under artifacts/research_20260925. Use claim_evidence_ledger_final.*;
the initial catalogue is preserved for audit. The finalizer corrects one SEERS
citation and adds historical controls plus exact-uniform comparisons.
CSV paths are relative to the project root. Markdown uses local D:/rnaexpress
links for the originating workspace; use matching archive paths elsewhere.

Portable replay (Python standard library only): extract either nested
results/research_20260921/srle_*replay_20260924.zip into a fresh directory, then
run `python -I -S -B replay.py` there. These independently implement aggregate
arithmetic only; they do not re-fit models, recount reads or verify source biology.

Full provenance/prediction verification requires the original repository and
its pinned public source files, saved predictions, count matrix and raw-file
receipts; large raw reads and historical runtime dependencies are not bundled.
Use the bundled Codex Python and the isolated runtime documented in common.py.
No installation, payment or unfiltered pytest is needed in the current workspace.

From D:/rnaexpress, with PYTHONDONTWRITEBYTECODE=1, PYTHONIOENCODING=utf-8,
OPENBLAS_NUM_THREADS=2 and OMP_NUM_THREADS=2:
python -m src.research_20260921.srle_measurement_lineage_20260925
python -m src.research_20260921.srle_clean_verification_20260925
python -m src.research_20260921.evidence_catalogue_20260925
python -m src.research_20260921.evidence_ledger_final_20260925
python -m src.research_20260921.package_evidence_20260925

Use a fresh output workspace for a full rebuild; writers preserve differing
existing records. Keep the delivered lineage_config.json for replay: it pins
the existing inputs and code. Do not regenerate the freeze to bless changes.
The scoped test log contains elapsed time and can differ on another machine.
Downloading historical SRLE source is optional: cached files/receipts are bundled.
No downloaded author code is executed by any replay.

Protected outcomes, old gates and unrelated edits remain unchanged. Discovery
of new datasets was blocked by prior automatic review and was not retried.
The inventory is not a global absence finding. No new external protocol or
outcome evaluation was executed without a qualified independent dataset.
